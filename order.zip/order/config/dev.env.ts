export const environment = {
    TYPE: 'mongodb',
    HOST: 'localhost',
    PORT: 27017,
    USERNAME: 'admin',
    PASSWORD: '112358',
    DATABASE: 'product',
    SERVER_PORT: 3002,
    PRODUCTION: true,
    AUTH_SOURCE: 'admin',
};
